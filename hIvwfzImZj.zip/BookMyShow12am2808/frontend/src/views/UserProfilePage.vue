<!-- <template>
  <UserNavBarComponent></UserNavBarComponent>
</template>



<script>
export default {
  name: "UserProfilePage",
  methods: {

    
  },
};
</script> -->
