<template>
  <div id="app">
    <!-- <VenueNavBarComponent></VenueNavBarComponent> -->
    <router-view/>
  </div>
</template>

<script>
// import VenueNavBarComponent from "@/components/VenueNavBarComponent.vue";

export default {
  name: 'App',
  // components: {
  //   VenueNavBarComponent,
  // },
}
</script>

<style scoped>
/* Add your scoped styles here if needed */
</style>















<!-- <template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'app',
  data() {
    return {

    }
  },
}
</script>

<style scoped>
</style> -->
