<!-- <template>
  <nav class="venue-navbar">
    <router-link to="/admin/venue" class="nav-link">Admin Venue</router-link>
    <router-link to="/admin/home" class="nav-link">Admin Home</router-link>
  </nav>
</template>

<script>
export default {
  name: "VenueNavBarComponent",
};
</script>

<style>
.venue-navbar {
  background-color: #333;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 10px;
}

.nav-link {
  color: white;
  text-decoration: none;
  margin: 0 10px;
}

.nav-link:hover {
  color: lightgray;
}
</style>

 -->
